package ds.implem;

import java.io.Serializable;

import ds.interfaces.MySet;

public abstract class AbstractSet<T> extends AbstractCollection<T> implements MySet<T>, Serializable{

	private static final long serialVersionUID = 1L;

	
}
