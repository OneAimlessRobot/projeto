#!/bin/bash
rm -r ./outputs/outputs*.txt
rm -r ./outputs2/outputs*.txt
rm -r $(find -name "*.class")
