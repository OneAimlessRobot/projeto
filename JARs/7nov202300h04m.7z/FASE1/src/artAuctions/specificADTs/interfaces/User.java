package artAuctions.specificADTs.interfaces;

public interface User extends UserGeneric {

	

	void removeBidsByWork(Work work);
	
}
