package artAuctions.exceptions;

public class WorkHasNoBidsInAuctionException extends Exception {

	private static final long serialVersionUID = 1L;

}
