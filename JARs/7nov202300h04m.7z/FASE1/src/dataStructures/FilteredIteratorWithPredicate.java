package dataStructures;

public interface FilteredIteratorWithPredicate<E> extends Iterator<E> {

	void nextEquals();
	

}
