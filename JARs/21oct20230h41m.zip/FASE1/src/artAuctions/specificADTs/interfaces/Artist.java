package artAuctions.specificADTs.interfaces;

public interface Artist extends User {

}
