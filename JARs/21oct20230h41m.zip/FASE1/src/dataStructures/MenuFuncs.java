package dataStructures;

public class MenuFuncs {

}
