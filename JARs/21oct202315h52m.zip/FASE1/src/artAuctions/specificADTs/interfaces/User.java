package artAuctions.specificADTs.interfaces;

import java.io.Serializable;

/**
* @author Adriano Antonio Campos Valente (NUMEROALUNO1) emailALUNO1
* @author Pedro Assuncao (NUMEROALUNO2) 
*/
public interface User extends Serializable {
	

	String getLogin();
}
