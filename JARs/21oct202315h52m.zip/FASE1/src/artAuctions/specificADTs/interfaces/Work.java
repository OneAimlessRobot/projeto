package artAuctions.specificADTs.interfaces;

import java.io.Serializable;

public interface Work extends Serializable {

}
