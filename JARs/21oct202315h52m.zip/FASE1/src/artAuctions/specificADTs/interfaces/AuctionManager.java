package artAuctions.specificADTs.interfaces;

import java.io.Serializable;

public interface AuctionManager extends Serializable{

}
