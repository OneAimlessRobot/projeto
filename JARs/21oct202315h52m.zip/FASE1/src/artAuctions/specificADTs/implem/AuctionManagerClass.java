package artAuctions.specificADTs.implem;

import java.io.Serializable;

import artAuctions.specificADTs.interfaces.AuctionManager;

public class AuctionManagerClass implements Serializable, AuctionManager {

	private static final long serialVersionUID = 1L;
 
}
