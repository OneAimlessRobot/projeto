package artAuctions.specificADTs.implem;

import java.io.Serializable;

import artAuctions.specificADTs.interfaces.Work;

public class WorkClass implements Serializable, Work {

}
