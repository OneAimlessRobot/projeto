package artAuctions.specificADTs.interfaces;

public interface Collector extends User{

}
