package artAuctions.specificADTs.interfaces;

public interface Artist extends User {

	
	String getArtsyName();
}

