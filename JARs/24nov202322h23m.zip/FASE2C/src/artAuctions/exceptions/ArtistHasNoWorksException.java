package artAuctions.exceptions;

public class ArtistHasNoWorksException extends Exception {

	private static final long serialVersionUID = 1L;

}
