

public abstract class Document{
	
	protected String title;
	protected String assunto;
	protected String cota;
	protected int id;
	
	
	
	
	
	
}