

public interface Copy{
	
	boolean getSituation();
	String getLocation();
	int getCopyCode();
	
	
}