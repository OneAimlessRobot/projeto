package dataStructures;

public abstract class AbstractQueue<E> implements Queue<E> {
	

}
