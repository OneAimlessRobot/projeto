

public class Book extends Document{
	
	private String author,
					ISBN,
					Publisher;
	
	
	public Book(String author, String isbn,String publisher) {
		
		this.setAuthor(author);
		this.setISBN(isbn);
		this.setPublisher(publisher);
		
		
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	public String getISBN() {
		return ISBN;
	}


	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}


	public String getPublisher() {
		return Publisher;
	}


	public void setPublisher(String publisher) {
		Publisher = publisher;
	}
	
}