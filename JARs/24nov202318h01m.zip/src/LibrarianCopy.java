

public interface LibrarianCopy extends Copy{
	
	
	void setSituation(boolean value);
	void setLocation(String location);
	void setCanBeBorrowed(boolean can);
	
	
}