package ds.prototypes;
import ds.exceptions.StackEmptyException;
import ds.interfaces.Bias;

public class BiasInDoubleList<T> implements Bias<T>{

	@Override
	public void push(T elem) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public T pop() throws StackEmptyException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T top() throws StackEmptyException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void popBack() throws StackEmptyException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public T back() throws StackEmptyException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void pushBack(T elem) {
		// TODO Auto-generated method stub
		
	}


}
