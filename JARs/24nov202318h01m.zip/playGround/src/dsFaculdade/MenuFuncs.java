package dsFaculdade;

public class MenuFuncs {

}
