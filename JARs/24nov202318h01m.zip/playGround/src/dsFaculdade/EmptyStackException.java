package dsFaculdade;

public class EmptyStackException extends RuntimeException{
    static final long serialVersionUID = 0L;
}

