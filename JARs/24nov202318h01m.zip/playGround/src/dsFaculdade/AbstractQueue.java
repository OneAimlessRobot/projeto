package dsFaculdade;

public abstract class AbstractQueue<E> implements Queue<E> {

	private static final long serialVersionUID = 1L;
	

}
