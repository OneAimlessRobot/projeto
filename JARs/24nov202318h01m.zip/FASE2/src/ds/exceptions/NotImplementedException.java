package ds.exceptions;

public class NotImplementedException extends RuntimeException {


	

	private static final long serialVersionUID = 9092664868331772306L;

	public NotImplementedException() {
		
		super("Nao implementado!!!!!");
		
	}
	
	
}
