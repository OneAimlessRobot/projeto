package ds.exceptions;

public class CollectionEmptyException extends Exception {

	
	private static final long serialVersionUID = -8356813091943757539L;

	public CollectionEmptyException() {
		
		super("Coleçao vazia!!!!");
		
	}
	
	
}
