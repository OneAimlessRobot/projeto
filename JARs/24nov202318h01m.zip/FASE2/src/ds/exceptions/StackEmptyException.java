package ds.exceptions;

public class StackEmptyException extends Exception {

	
	private static final long serialVersionUID = 7028805726866286524L;

	public StackEmptyException() {
		
		super("Stack vazia!!!!");
		
	}
	
	
}
