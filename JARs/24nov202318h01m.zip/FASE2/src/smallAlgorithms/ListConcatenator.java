package smallAlgorithms;

import ds.interfaces.List;

public interface ListConcatenator {
	
	<T> List<T> concatenate(List<T> l1,List<T> l2);

}
