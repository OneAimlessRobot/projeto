#!/bin/bash

rm -r $(find -name "*.class")
