#!/bin/bash
rm -r ./outputs/outputs*.txt
rm -r $(find -name "*.class")
