package artAuctions.exceptions;
/**
* @author Adriano Antonio Campos Valente (62411) aa.valente@campus.fct.unl.pt
* @author Pedro Miguel Martino Assuncao (68840) pedroassuncao@gmail.com
*/


import java.io.Serializable;

public class UserExistsException extends Exception implements Serializable {

	private static final long serialVersionUID = 1L;

}
