package artAuctions.exceptions;

public class NoSoldWorksException extends Exception {

	private static final long serialVersionUID = 1L;

}
