package dataStructures.interfaces;

public interface InvertibleQueue<E> extends Queue<E> {

	void invert();
}
